﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk;
using Microsoft.PowerPlatform.Dataverse.Client;
using Microsoft.Xrm.Sdk.Query;
using System.Configuration;

namespace CaseResolutionTimeUpdate
{
    class Program
    {
        static void Main(string[] args)
        {
            string connStr = ConfigurationManager.ConnectionStrings["D365Connection"].ConnectionString;

            using (var service = new ServiceClient(connStr))
            {
                if (!service.IsReady)
                {
                    Console.WriteLine("Connection failed.");
                    return;
                }

                int pageNumber = 1;
                int recordCount = 0;
                bool moreRecords = true;

                while (moreRecords)
                {

                    var query = new QueryExpression("incident")
                    {
                        ColumnSet = new ColumnSet("incidentid", "createdon", "new_resolutiondate"),
                        PageInfo = new PagingInfo
                        {
                            Count = 5000,
                            PageNumber = pageNumber
                        }
                    };

                    query.Criteria.FilterOperator = LogicalOperator.And;
                    query.Criteria.AddCondition("statecode", ConditionOperator.Equal, 1); // Resolved
                    query.Criteria.AddCondition("new_resolutiondate", ConditionOperator.NotNull); // Contains Data
                    query.Criteria.AddCondition("new_resolutiontimeinminutes", ConditionOperator.Equal, 0); // Contains Data

                    var results = service.RetrieveMultiple(query);

                    foreach (var entity in results.Entities)
                    {
                        recordCount++;
                        // Your logic: update resolution time etc.
                        Console.WriteLine($"Case ID: {entity.Id}");

                        Guid caseId = entity.Id;
                        DateTime? createdOn = entity.GetAttributeValue<DateTime?>("createdon");
                        DateTime? resolvedOn = entity.GetAttributeValue<DateTime?>("new_resolutiondate");

                        if (createdOn.HasValue && resolvedOn.HasValue)
                        {
                            int weekdays = CountWeekdays(createdOn.Value, resolvedOn.Value);
                            int resolutionMinutes = weekdays * 480;

                            Entity update = new Entity("incident", caseId);
                            update["new_resolutiontimeinminutes"] = resolutionMinutes;
                            service.Update(update);

                            Console.WriteLine($"Updated Case {caseId} | Weekdays: {weekdays} | Minutes: {resolutionMinutes}");
                        }
                    }

                    moreRecords = results.MoreRecords;
                    if (moreRecords)
                    {
                        pageNumber++;
                        query.PageInfo.PagingCookie = results.PagingCookie; // optional, auto-used by SDK
                    }
                }

                Console.WriteLine($"Completed. Total records processed: {recordCount}");
            }
        }
        static int CountWeekdays(DateTime start, DateTime end)
        {
            int count = 0;
            for (DateTime dt = start.Date; dt <= end.Date; dt = dt.AddDays(1))
            {
                if (dt.DayOfWeek != DayOfWeek.Saturday && dt.DayOfWeek != DayOfWeek.Sunday)
                    count++;
            }
            return count;
        }
    }
}
